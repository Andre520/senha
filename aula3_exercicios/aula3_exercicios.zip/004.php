<?php
/*
Escreva um script que imprima qual o maior número.
Use IF
*/
$a = 10;
$b = 1;
$c = 40;
  
if($a < $b && $a < $c){
    echo $a;
}

if($b < $a && $b < $c){
    echo $b;

}
if ($c < $a && $c < $b){
    echo $c;
}
if ($a == $b && $c == $a && $b == $a && $b && $c){
    echo "Os numeros não são iguais"
}



?>