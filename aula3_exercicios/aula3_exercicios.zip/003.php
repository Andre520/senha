<?php
/*
Escreva um script que imprima qual o maior número.
Converter variáveis strings em inteiros
Use IF
*/
$a = "10";
$b = "1";

$intA=intval ($a);
$intB=intval ($b);


if ($intvalA > $intvalB){
    echo $intA;
}
else ($intvalA < $intvalB){
    echo $intB;
}
?>